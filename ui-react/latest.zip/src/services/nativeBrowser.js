import { bridge, subscribe } from './bridge'

const blankTab = (id = `tab-${Date.now()}`) => ({
  id: String(id),
  type: 'new-tab',
  title: 'New Tab',
  url: '',
  icon: null,
})

function normalizeTab(raw) {
  if (!raw) return null
  const url = String(raw.url || raw.currentUrl || '')
  return {
    id: String(raw.id ?? raw.tabId ?? `tab-${Date.now()}`),
    type: url ? 'web' : 'new-tab',
    title: String(raw.title || (url ? url.replace(/^https?:\/\//, '').split('/')[0] : 'New Tab')),
    url,
    icon: raw.icon || raw.favicon || null,
  }
}

function extractTabs(result) {
  const list = Array.isArray(result) ? result : result?.tabs
  return Array.isArray(list) ? list.map(normalizeTab).filter(Boolean) : []
}

export function createNativeBrowserAdapter(set, get) {
  let cancelSubscription = null
  let started = false
  let sessionTimer = null

  const replaceTabs = (nextTabs, activeId) => {
    const tabs = nextTabs.length ? nextTabs : [blankTab()]
    set((state) => ({
      tabs,
      activeTabId: activeId ? String(activeId) : state.activeTabId && tabs.some((tab) => tab.id === state.activeTabId) ? state.activeTabId : tabs[0].id,
      nativeReady: true,
    }))
  }

  const updateTab = (id, patch) => {
    if (id == null) return
    const tabId = String(id)
    set((state) => ({
      tabs: state.tabs.map((tab) => tab.id === tabId ? { ...tab, ...patch, type: patch.url ? 'web' : tab.type } : tab),
    }))
  }

  const persistSession = () => {
    clearTimeout(sessionTimer)
    sessionTimer = setTimeout(() => {
      const state = get()
      bridge.sessionSet({
        tabs: state.tabs.map(({ id, title, url }) => ({ id, title, url })),
        activeTabId: state.activeTabId,
      }).catch(() => {})
    }, 150)
  }

  const onEvent = (event) => {
    if (!event?.type) return
    const id = event.tabId ?? event.id
    switch (event.type) {
      case 'tab.created': {
        const tab = normalizeTab({ ...event, id })
        if (!tab) return
        set((state) => ({
          tabs: state.tabs.some((item) => item.id === tab.id) ? state.tabs.map((item) => item.id === tab.id ? { ...item, ...tab } : item) : [...state.tabs, tab],
          activeTabId: event.activate ? tab.id : state.activeTabId,
          nativeReady: true,
        }))
        break
      }
      case 'tab.activated':
        if (id != null) set({ activeTabId: String(id), nativeReady: true })
        break
      case 'tab.closed':
        set((state) => {
          const tabs = state.tabs.filter((tab) => tab.id !== String(id))
          const safeTabs = tabs.length ? tabs : [blankTab()]
          return { tabs: safeTabs, activeTabId: safeTabs.some((tab) => tab.id === state.activeTabId) ? state.activeTabId : safeTabs[0].id }
        })
        break
      case 'navigate':
      case 'address':
      case 'loading':
      case 'title': {
        const url = event.url || ''
        updateTab(id ?? get().activeTabId, { ...(url ? { url, type: 'web' } : {}), ...(event.title ? { title: event.title } : {}) })
        break
      }
      case 'session': {
        const tabs = extractTabs(event)
        if (tabs.length) replaceTabs(tabs, event.activeTabId)
        break
      }
      default:
        break
    }
    persistSession()
  }

  async function start() {
    if (started) return
    started = true
    try {
      const session = await bridge.sessionGet()
      const sessionTabs = extractTabs(session?.session)
      if (sessionTabs.length) replaceTabs(sessionTabs, session.session.activeTabId)
    } catch (_) {}

    try {
      const result = await bridge.tabsList()
      const tabs = extractTabs(result)
      if (tabs.length) replaceTabs(tabs, result.activeTabId ?? result.activeId)
    } catch (_) {}

    if (!get().tabs.length) replaceTabs([blankTab()])
    try {
      const handle = await subscribe('browser', onEvent)
      cancelSubscription = handle?.cancel || null
    } catch (_) {
      set({ nativeReady: false })
    }
  }

  function stop() {
    cancelSubscription?.()
    cancelSubscription = null
    clearTimeout(sessionTimer)
    started = false
  }

  function openTab(initialUrl = '') {
    const id = `tab-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
    const tab = blankTab(id)
    set((state) => ({ tabs: [...state.tabs, tab], activeTabId: id }))
    bridge.browserEnsureTab(id).catch(() => {})
    bridge.browserActivateTab(id).catch(() => {})
    if (initialUrl) navigate(initialUrl, id)
    persistSession()
    return id
  }

  function closeTab(id) {
    const tabId = String(id)
    bridge.browserCloseTab(tabId).catch(() => {})
    set((state) => {
      if (state.tabs.length <= 1) return state
      const index = state.tabs.findIndex((tab) => tab.id === tabId)
      const tabs = state.tabs.filter((tab) => tab.id !== tabId)
      return { tabs, activeTabId: state.activeTabId === tabId ? tabs[Math.min(index, tabs.length - 1)].id : state.activeTabId }
    })
    persistSession()
  }

  function activateTab(id) {
    const tabId = String(id)
    set({ activeTabId: tabId })
    bridge.browserActivateTab(tabId).catch(() => {})
    persistSession()
  }

  function navigate(raw, id = get().activeTabId) {
    const value = String(raw || '').trim()
    if (!value) return
    const url = /^(https?:|file:|about:|mesh:)/i.test(value) ? value : `https://www.google.com/search?q=${encodeURIComponent(value)}`
    const tabId = String(id)
    updateTab(tabId, { url, type: 'web', title: url.replace(/^https?:\/\//, '').split('/')[0] || 'Loading…' })
    bridge.browserEnsureTab(tabId).catch(() => {})
    bridge.browserActivateTab(tabId).catch(() => {})
    bridge.browserShow(true).catch(() => {})
    bridge.browserNavigate(url, tabId).catch(() => {})
    set({ reloadingTabId: tabId })
    setTimeout(() => set((state) => state.reloadingTabId === tabId ? { reloadingTabId: null } : state), 350)
    persistSession()
  }

  function goBack() { bridge.browserBack().catch(() => {}) }
  function goForward() { bridge.browserForward().catch(() => {}) }
  function reload() { bridge.browserReload(false).catch(() => {}) }
  function goHome() {
    const id = get().activeTabId
    bridge.browserClear().catch(() => {})
    set((state) => ({ tabs: state.tabs.map((tab) => tab.id === id ? { ...blankTab(id) } : tab) }))
    bridge.browserShow(false).catch(() => {})
    persistSession()
  }

  return { start, stop, openTab, closeTab, activateTab, navigate, goBack, goForward, reload, goHome }
}
