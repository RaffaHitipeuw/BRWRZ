#pragma once

#include <map>

#include "include/cef_menu_model.h"
#include "include/cef_menu_model_delegate.h"
#include "nlohmann/json.hpp"

namespace mesh {

class MeshHandler;

// Native Views app menu (Chrome/Brave MenuRunner path).
class AppMenuDelegate : public CefMenuModelDelegate {
 public:
  AppMenuDelegate(MeshHandler* owner, const nlohmann::json& payload);
  ~AppMenuDelegate() override = default;

  CefRefPtr<CefMenuModel> Build();

  void ExecuteCommand(CefRefPtr<CefMenuModel> menu_model,
                      int command_id,
                      cef_event_flags_t event_flags) override;
  void MenuWillShow(CefRefPtr<CefMenuModel> menu_model) override;
  void MenuClosed(CefRefPtr<CefMenuModel> menu_model) override;

 private:
  void Emit(const nlohmann::json& command);

  MeshHandler* owner_;
  nlohmann::json payload_;
  std::map<int, nlohmann::json> commands_;
  CefRefPtr<CefMenuModel> root_;

  IMPLEMENT_REFCOUNTING(AppMenuDelegate);
};

}  // namespace mesh
