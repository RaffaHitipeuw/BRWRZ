#include "mesh/mesh_handler.h"

#include <algorithm>
#include <cstdio>
#include <sstream>
#include <string>
#include <vector>

#include "include/cef_app.h"
#include "include/cef_browser.h"
#include "include/cef_parser.h"
#include "include/base/cef_callback.h"
#include "include/views/cef_box_layout.h"
#include "include/views/cef_browser_view.h"
#include "include/views/cef_layout.h"
#include "include/views/cef_menu_button.h"
#include "include/views/cef_window.h"
#include "include/wrapper/cef_closure_task.h"
#include "include/wrapper/cef_helpers.h"
#include "include/cef_cookie.h"
#include "mesh/adblock_resource_handler.h"
#include "mesh/agent_api.h"
#include "mesh/ai_hud.h"
#include "mesh/appearance.h"
#include "mesh/log.h"
#include "mesh/adblock_service.h"
#include "mesh/app_menu_button.h"
#include "mesh/dev_mode.h"
#include "mesh/download_store.h"
#include "mesh/devtools_client.h"
#include "mesh/library_ipc.h"
#include "mesh/mcp/mcp_server.h"
#include "mesh/paths.h"
#include "mesh/scrollbar_inject.h"
#include "mesh/utf8.h"
#include "engine/engine_app_menu_anchor.h"
#include "engine/engine_keyboard_policy.h"
#include "engine/engine_native_menu_tracker.h"
#include "engine/engine_runtime_policy.h"
#include "engine/engine_window_delegate.h"

#if defined(OS_WIN)
#include <windows.h>
#include <psapi.h>
#include <shellapi.h>
#pragma comment(lib, "psapi.lib")
#endif

#include <chrono>
#include <filesystem>
#include <fstream>
#if defined(OS_LINUX)
#include <unistd.h>
#endif

namespace mesh {
namespace {

MeshHandler* g_instance = nullptr;

constexpr size_t kMaxContentTabs = 16;

std::string GetDataURI(const std::string& data, const std::string& mime_type) {
  return "data:" + mime_type + ";base64," +
         CefURIEncode(CefBase64Encode(data.data(), data.size()), false)
             .ToString();
}

// StopLoad during the first about:blank document crashes CEF Alloy views.
void SafeStopLoad(CefRefPtr<CefBrowser> browser) {
  if (!browser || !browser->IsLoading()) {
    return;
  }
  auto frame = browser->GetMainFrame();
  const std::string url =
      (frame && frame->IsValid()) ? frame->GetURL().ToString() : std::string();
  if (engine::IsAboutUrl(url)) {
    return;
  }
  browser->StopLoad();
}

#if defined(OS_WIN)
// Native window icon. The resource id lives in native/win/resource.h.
constexpr int kAppIconId = 101;

void ApplyAppIcon(CefRefPtr<CefWindow> window) {
  if (!window) {
    return;
  }
  HWND hwnd = window->GetWindowHandle();
  if (!hwnd) {
    return;
  }
  HINSTANCE inst = GetModuleHandleW(nullptr);
  auto load = [inst](int metric) -> HICON {
    return static_cast<HICON>(LoadImageW(
        inst, MAKEINTRESOURCEW(kAppIconId), IMAGE_ICON,
        GetSystemMetrics(metric), GetSystemMetrics(metric), LR_DEFAULTCOLOR));
  };
  if (HICON big = load(SM_CXICON)) {
    SendMessageW(hwnd, WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(big));
  }
  if (HICON small = load(SM_CXSMICON)) {
    SendMessageW(hwnd, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(small));
  }
}
#endif

}  // namespace

MeshHandler::MeshHandler(bool alloy_style) : alloy_style_(alloy_style) {
  DCHECK(!g_instance);
  g_instance = this;

  paths::EnsureAppDataDir();
  if (!repository_.Open(paths::DatabasePath())) {
    LOG(ERROR) << "Failed to open library database";
  }
}

MeshHandler::~MeshHandler() {
  DestroyAiHud();
  hot_reload_.Stop();
  // The native menu tracker is a process-wide singleton that holds the
  // callbacks of this handler. It must not outlive them.
  engine::NativeMenuTracker::Get().Remove();
  g_instance = nullptr;
}

MeshHandler* MeshHandler::GetInstance() {
  return g_instance;
}

void MeshHandler::SetShellBrowserView(CefRefPtr<CefBrowserView> view) {
  shell_browser_view_ = view;
}

void MeshHandler::SetContentBrowserView(CefRefPtr<CefBrowserView> view) {
  if (view) {
    recycled_content_views_.push_back(view);
  }
}

void MeshHandler::SetOverlayBrowserView(CefRefPtr<CefBrowserView> view) {
  overlay_browser_view_ = view;
}

void MeshHandler::SetOverlayController(
    CefRefPtr<CefOverlayController> controller) {
  overlay_controller_ = controller;
}

CefRefPtr<CefBrowserView> MeshHandler::ActiveContentView() const {
  if (active_tab_id_.empty()) {
    return nullptr;
  }
  return ContentViewForTab(active_tab_id_);
}

CefRefPtr<CefBrowserView> MeshHandler::ContentViewForTab(
    const std::string& tab_id) const {
  if (tab_id.empty()) {
    return nullptr;
  }
  const auto it = tab_content_views_.find(tab_id);
  if (it == tab_content_views_.end()) {
    return nullptr;
  }
  return it->second;
}

std::string MeshHandler::TabIdForContentBrowser(
    CefRefPtr<CefBrowser> browser) const {
  if (!browser) {
    return {};
  }
  auto view = CefBrowserView::GetForBrowser(browser);
  if (!view) {
    return {};
  }
  for (const auto& entry : tab_content_views_) {
    if (entry.second && entry.second->IsSame(view)) {
      return entry.first;
    }
  }
  return {};
}

bool MeshHandler::IsContentBrowser(CefRefPtr<CefBrowser> browser) const {
  if (!browser) {
    return false;
  }
  {
    std::lock_guard<std::mutex> lock(browser_ids_mu_);
    if (devtools_browser_ids_.count(browser->GetIdentifier()) > 0) {
      return false;
    }
    if (content_browser_ids_.count(browser->GetIdentifier()) > 0) {
      return true;
    }
  }
  if (!TabIdForContentBrowser(browser).empty()) {
    return true;
  }
  for (const auto& recycled : recycled_content_views_) {
    if (recycled) {
      if (auto content = recycled->GetBrowser()) {
        if (content->IsSame(browser)) {
          return true;
        }
      }
    }
  }
  return false;
}

bool MeshHandler::ShouldFilterNetwork(CefRefPtr<CefBrowser> browser) const {
  if (!browser) {
    // Service worker / CefURLRequest traffic without a browser: filter it
    // like Brave filters everything that is not app UI.
    return true;
  }
  const int id = browser->GetIdentifier();
  std::lock_guard<std::mutex> lock(browser_ids_mu_);
  if (id == shell_browser_id_ || id == overlay_browser_id_ ||
      devtools_browser_ids_.count(id) > 0) {
    return false;
  }
  // Known content pane, or any unknown browser (popups, recycled views):
  // default to filtering — app chrome is always registered as shell/overlay.
  return true;
}

void MeshHandler::RegisterBrowserPane(CefRefPtr<CefBrowser> browser,
                                      BrowserPane pane) {
  if (!browser) {
    return;
  }
  const int id = browser->GetIdentifier();
  std::lock_guard<std::mutex> lock(browser_ids_mu_);
  switch (pane) {
    case BrowserPane::Shell:
      shell_browser_id_ = id;
      content_browser_ids_.erase(id);
      break;
    case BrowserPane::Overlay:
      overlay_browser_id_ = id;
      content_browser_ids_.erase(id);
      break;
    case BrowserPane::Content:
      if (devtools_browser_ids_.count(id) == 0) {
        content_browser_ids_.insert(id);
      }
      break;
    case BrowserPane::DevTools:
      devtools_browser_ids_.insert(id);
      content_browser_ids_.erase(id);
      break;
  }
}

void MeshHandler::UnregisterBrowserPane(CefRefPtr<CefBrowser> browser) {
  if (!browser) {
    return;
  }
  const int id = browser->GetIdentifier();
  std::lock_guard<std::mutex> lock(browser_ids_mu_);
  content_browser_ids_.erase(id);
  if (shell_browser_id_ == id) {
    shell_browser_id_ = -1;
  }
  if (overlay_browser_id_ == id) {
    overlay_browser_id_ = -1;
  }
  devtools_browser_ids_.erase(id);
}

void MeshHandler::RegisterDevToolsBrowser(CefRefPtr<CefBrowser> browser) {
  if (!browser) {
    return;
  }
  const int id = browser->GetIdentifier();
  std::lock_guard<std::mutex> lock(browser_ids_mu_);
  devtools_browser_ids_.insert(id);
  content_browser_ids_.erase(id);
}

bool MeshHandler::IsDevToolsBrowser(CefRefPtr<CefBrowser> browser) const {
  if (!browser) {
    return false;
  }
  {
    std::lock_guard<std::mutex> lock(browser_ids_mu_);
    if (devtools_browser_ids_.count(browser->GetIdentifier()) > 0) {
      return true;
    }
  }
  if (auto frame = browser->GetMainFrame()) {
    return engine::IsDevToolsUrl(frame->GetURL().ToString());
  }
  return false;
}

void MeshHandler::TrackBrowserIdentity(CefRefPtr<CefBrowser> browser) {
  if (!browser) {
    return;
  }
  const int id = browser->GetIdentifier();
  std::lock_guard<std::mutex> lock(browser_ids_mu_);
  // Prefer view-map classification on the UI thread (caller).
  if (shell_browser_view_) {
    if (auto shell = shell_browser_view_->GetBrowser()) {
      if (shell->IsSame(browser)) {
        shell_browser_id_ = id;
        content_browser_ids_.erase(id);
        return;
      }
    }
  }
  if (overlay_browser_view_) {
    if (auto overlay = overlay_browser_view_->GetBrowser()) {
      if (overlay->IsSame(browser)) {
        overlay_browser_id_ = id;
        content_browser_ids_.erase(id);
        return;
      }
    }
  }
  if (devtools_browser_ids_.count(id) > 0) {
    content_browser_ids_.erase(id);
    return;
  }
  if (!TabIdForContentBrowser(browser).empty()) {
    content_browser_ids_.insert(id);
    return;
  }
  for (const auto& recycled : recycled_content_views_) {
    if (recycled) {
      if (auto content = recycled->GetBrowser()) {
        if (content->IsSame(browser)) {
          content_browser_ids_.insert(id);
          return;
        }
      }
    }
  }
}

void MeshHandler::UntrackBrowserIdentity(CefRefPtr<CefBrowser> browser) {
  if (!browser) {
    return;
  }
  const int id = browser->GetIdentifier();
  content_seed_idle_ids_.erase(id);
  recycling_content_browser_ids_.erase(id);
  std::lock_guard<std::mutex> lock(browser_ids_mu_);
  content_browser_ids_.erase(id);
  if (shell_browser_id_ == id) {
    shell_browser_id_ = -1;
  }
  if (overlay_browser_id_ == id) {
    overlay_browser_id_ = -1;
  }
  devtools_browser_ids_.erase(id);
}

bool MeshHandler::IsShellBrowser(CefRefPtr<CefBrowser> browser) const {
  if (!browser) {
    return false;
  }
  const int id = browser->GetIdentifier();
  {
    std::lock_guard<std::mutex> lock(browser_ids_mu_);
    if (shell_browser_id_ != -1 && id == shell_browser_id_) {
      return true;
    }
  }
  if (!shell_browser_view_) {
    return false;
  }
  auto shell = shell_browser_view_->GetBrowser();
  return shell && shell->IsSame(browser);
}

bool MeshHandler::IsOverlayBrowser(CefRefPtr<CefBrowser> browser) const {
  if (!browser) {
    return false;
  }
  const int id = browser->GetIdentifier();
  {
    std::lock_guard<std::mutex> lock(browser_ids_mu_);
    if (overlay_browser_id_ != -1 && id == overlay_browser_id_) {
      return true;
    }
  }
  if (!overlay_browser_view_) {
    return false;
  }
  auto overlay = overlay_browser_view_->GetBrowser();
  return overlay && overlay->IsSame(browser);
}

CefRefPtr<CefBrowser> MeshHandler::ContentBrowser() const {
  if (auto view = ActiveContentView()) {
    return view->GetBrowser();
  }
  return nullptr;
}

bool MeshHandler::IsContentSeedIdle(CefRefPtr<CefBrowser> browser) const {
  return browser && content_seed_idle_ids_.count(browser->GetIdentifier()) > 0;
}

void MeshHandler::MarkContentSeedIdle(CefRefPtr<CefBrowser> browser) {
  if (browser) {
    content_seed_idle_ids_.insert(browser->GetIdentifier());
  }
}

void MeshHandler::ClearContentSeedIdle(CefRefPtr<CefBrowser> browser) {
  if (browser) {
    content_seed_idle_ids_.erase(browser->GetIdentifier());
  }
}

bool MeshHandler::ContentViewIsBooting(CefRefPtr<CefBrowserView> view) const {
  if (!view) {
    return false;
  }
  auto browser = view->GetBrowser();
  if (!browser) {
    return true;
  }
  return !IsContentSeedIdle(browser);
}

bool MeshHandler::AnyContentViewBooting() const {
  for (const auto& entry : tab_content_views_) {
    if (ContentViewIsBooting(entry.second)) {
      return true;
    }
  }
  for (const auto& view : recycled_content_views_) {
    if (ContentViewIsBooting(view)) {
      return true;
    }
  }
  return false;
}

bool MeshHandler::EnsureContentTab(const std::string& tab_id) {
  CEF_REQUIRE_UI_THREAD();
  if (tab_id.empty()) {
    return false;
  }
  if (ContentViewForTab(tab_id)) {
    return true;
  }
  if (tab_content_views_.size() >= kMaxContentTabs) {
    mesh::Log("EnsureContentTab: refusing new tab, max " +
              std::to_string(kMaxContentTabs) + " reached");
    return false;
  }

  CefRefPtr<CefBrowserView> view;
  while (!recycled_content_views_.empty() && !view) {
    view = recycled_content_views_.back();
    recycled_content_views_.pop_back();
    // Keep views whose browser is not attached yet (seed pane created in
    // OnContextInitialized). Dropping them created a second Alloy view and
    // left the seed child in the window tree — Wikipedia restore then CHECKs.
  }
  if (view) {
    if (auto browser = view->GetBrowser()) {
      recycling_content_browser_ids_.insert(browser->GetIdentifier());
      if (auto frame = browser->GetMainFrame()) {
        const std::string current = frame->GetURL().ToString();
        if (!engine::IsAboutUrl(current)) {
          ClearContentSeedIdle(browser);
          SafeStopLoad(browser);
          frame->LoadURL("about:blank");
        }
      }
    }
    mesh::Log("EnsureContentTab: reuse view for " + tab_id);
  } else {
    if (AnyContentViewBooting()) {
      mesh::Log("EnsureContentTab: defer new Alloy view for " + tab_id +
                " (another content seed still attaching)");
      const std::string tab_copy = tab_id;
      CefPostDelayedTask(
          TID_UI,
          base::BindOnce(
              [](std::string id) {
                if (auto* handler = MeshHandler::GetInstance()) {
                  if (handler->EnsureContentTab(id)) {
                    handler->FlushPendingContentUrl(id);
                  }
                }
              },
              tab_copy),
          250);
      return false;
    }
    if (!shell_browser_view_) {
      return false;
    }
    auto window = shell_browser_view_->GetWindow();
    if (!window) {
      return false;
    }
    const cef_runtime_style_t runtime_style =
        alloy_style_ ? CEF_RUNTIME_STYLE_ALLOY : CEF_RUNTIME_STYLE_CHROME;
    CefBrowserSettings content_settings;
    CefRefPtr<engine::EngineBrowserViewDelegate> content_delegate(
        new engine::EngineBrowserViewDelegate(runtime_style,
                                              BrowserPane::Content, this));
    view = CefBrowserView::CreateBrowserView(this, "about:blank",
                                             content_settings, nullptr,
                                             nullptr, content_delegate);
    if (!view) {
      return false;
    }
    window->AddChildViewAt(view, 1);
    view->SetVisible(false);
    mesh::Log("EnsureContentTab: created view for " + tab_id);
  }

  tab_content_views_[tab_id] = view;
  if (auto browser = view->GetBrowser()) {
    TrackBrowserIdentity(browser);
  }
  return true;
}

bool MeshHandler::ActivateContentTab(const std::string& tab_id) {
  CEF_REQUIRE_UI_THREAD();
  active_tab_id_ = tab_id;
  const bool has_view = ContentViewForTab(tab_id) != nullptr;
  content_visible_ = has_view;
  LayoutContentBrowser();
  EmitBrowserEvent(Json{{"type", "visibility"},
                        {"visible", content_visible_},
                        {"tabId", tab_id}});
  return has_view;
}

void MeshHandler::CloseContentTab(const std::string& tab_id) {
  CEF_REQUIRE_UI_THREAD();
  if (tab_id.empty()) {
    return;
  }
  auto it = tab_content_views_.find(tab_id);
  if (it == tab_content_views_.end()) {
    tab_audio_playing_.erase(tab_id);
    tab_media_.erase(tab_id);
    tab_titles_.erase(tab_id);
    pending_content_urls_.erase(tab_id);
    EmitBrowserEvent(Json{{"type", "media"},
                          {"tabId", tab_id},
                          {"active", false},
                          {"playing", false}});
    if (active_tab_id_ == tab_id) {
      active_tab_id_.clear();
      content_visible_ = false;
      LayoutContentBrowser();
    }
    return;
  }

  CefRefPtr<CefBrowserView> view = it->second;
  tab_content_views_.erase(it);
  tab_audio_playing_.erase(tab_id);
  tab_media_.erase(tab_id);
  tab_titles_.erase(tab_id);
  pending_content_urls_.erase(tab_id);
  EmitBrowserEvent(Json{{"type", "media"},
                        {"tabId", tab_id},
                        {"active", false},
                        {"playing", false}});

  if (view) {
    view->SetVisible(false);

    if (auto browser = view->GetBrowser()) {
      recycling_content_browser_ids_.insert(browser->GetIdentifier());
      if (auto frame = browser->GetMainFrame()) {
        const std::string current = frame->GetURL().ToString();
        // Closing a still-booting New Tab must not StopLoad/LoadURL. Session
        // restore does this ~3s after start, then Wikipedia navigates on the
        // sibling view and CEF CHECKs.
        if (!engine::IsAboutUrl(current)) {
          ClearContentSeedIdle(browser);
          SafeStopLoad(browser);
          frame->LoadURL("about:blank");
        }
      }
    }
    mesh::Log("CloseContentTab: " + tab_id);
    if (recycled_content_views_.size() < 12) {
      recycled_content_views_.push_back(view);
    } else {
      if (auto browser = view->GetBrowser()) {
        browser->GetHost()->CloseBrowser(false);
      }
    }
  }

  if (active_tab_id_ == tab_id) {
    active_tab_id_.clear();
    content_visible_ = false;
  }
  LayoutContentBrowser();
}

bool MeshHandler::OpenInContentBrowser(const std::string& url) {
  if (!engine::ShouldOpenInContent(url)) {
    return false;
  }
  return ContentNavigate(url);
}

bool MeshHandler::ContentNavigate(const std::string& url) {
  return ContentNavigate(url, active_tab_id_);
}

bool MeshHandler::ContentNavigate(const std::string& url,
                                  const std::string& tab_id) {
  CEF_REQUIRE_UI_THREAD();
  std::string id = tab_id;
  if (id.empty()) {
    id = active_tab_id_;
  }
  if (id.empty()) {
    return false;
  }
  if (!EnsureContentTab(id)) {
    if (!shell_browser_view_ || tab_content_views_.size() >= kMaxContentTabs) {
      return false;
    }
    pending_content_urls_[id] = url;
    mesh::Log("ContentNavigate: waiting for view " + url + " tab=" + id);
    return true;
  }
  if (active_tab_id_ != id) {
    active_tab_id_ = id;
  }

  auto view = ContentViewForTab(id);
  if (!view) {
    return false;
  }
  auto browser = view->GetBrowser();
  CefRefPtr<CefFrame> frame = browser ? browser->GetMainFrame() : nullptr;

  // Seed content views start on about:blank. LoadURL of Wikipedia (or any
  // real page) before that first document finishes CHECKs CEF Alloy.
  const bool booting = !browser || !frame || !frame->IsValid() ||
                       !IsContentSeedIdle(browser);
  if (booting) {
    const bool already_queued = pending_content_urls_.count(id) > 0;
    pending_content_urls_[id] = url;
    active_tab_id_ = id;
    content_visible_ = true;
    LayoutContentBrowser();
    mesh::Log("ContentNavigate: queued " + url + " for " + id +
              (browser ? " (seed not idle)" : " (no browser)"));
    if (!already_queued) {
      const std::string tab_copy = id;
      CefPostDelayedTask(
          TID_UI,
          base::BindOnce(
              [](std::string tab_id) {
                if (auto* handler = MeshHandler::GetInstance()) {
                  if (auto view = handler->ContentViewForTab(tab_id)) {
                    handler->MarkContentSeedIdle(view->GetBrowser());
                  }
                  handler->FlushPendingContentUrl(tab_id);
                }
              },
              tab_copy),
          5000);
    }
    return true;
  }

  pending_content_urls_.erase(id);

  mesh::Log("ContentNavigate: " + url + " tab=" + id);
  // Cancel in-flight loads only after the seed document is gone.
  SafeStopLoad(browser);
  // Load before revealing the pane so the previous page is never flashed.
  frame->LoadURL(url);

  content_visible_ = true;
  LayoutContentBrowser();

  EmitContentEvent(browser,
                   Json{{"type", "navigate"},
                        {"url", url},
                        {"visible", true},
                        {"loading", true},
                        {"canGoBack", browser->CanGoBack()},
                        {"canGoForward", browser->CanGoForward()}});

  CefPostDelayedTask(TID_UI, base::BindOnce([]() {
                       if (auto* handler = MeshHandler::GetInstance()) {
                         handler->LayoutContentBrowser();
                       }
                     }),
                     48);
  return true;
}

void MeshHandler::FlushPendingContentUrl(const std::string& tab_id) {
  CEF_REQUIRE_UI_THREAD();
  if (tab_id.empty()) {
    return;
  }
  const auto pending = pending_content_urls_.find(tab_id);
  if (pending == pending_content_urls_.end()) {
    return;
  }
  const std::string url = pending->second;
  if (url.empty() || url == "about:blank") {
    pending_content_urls_.erase(pending);
    return;
  }
  ContentNavigate(url, tab_id);
}

void MeshHandler::ContentGoBack() {
  CEF_REQUIRE_UI_THREAD();
  auto browser = ContentBrowser();
  if (!browser || !browser->CanGoBack()) {
    return;
  }
  SafeStopLoad(browser);
  browser->GoBack();
}

void MeshHandler::ContentGoForward() {
  CEF_REQUIRE_UI_THREAD();
  auto browser = ContentBrowser();
  if (!browser || !browser->CanGoForward()) {
    return;
  }
  SafeStopLoad(browser);
  browser->GoForward();
}

void MeshHandler::ContentReload(bool ignore_cache) {
  CEF_REQUIRE_UI_THREAD();
  auto browser = ContentBrowser();
  if (!browser) {
    return;
  }
  if (ignore_cache) {
    browser->ReloadIgnoreCache();
  } else {
    browser->Reload();
  }
}

bool MeshHandler::OnPreKeyEvent(CefRefPtr<CefBrowser> browser,
                                const CefKeyEvent& event,
                                CefEventHandle os_event,
                                bool* is_keyboard_shortcut) {
  CEF_REQUIRE_UI_THREAD();
  (void)os_event;
  (void)is_keyboard_shortcut;

  if (!browser) {
    return false;
  }
  if (event.type != KEYEVENT_RAWKEYDOWN && event.type != KEYEVENT_KEYDOWN) {
    return false;
  }

  // The engine owns the shortcut routing; the product owns the actions.
  engine::KeyEvent key_event;
  key_event.key_code = event.windows_key_code;
  key_event.ctrl = (event.modifiers & EVENTFLAG_CONTROL_DOWN) != 0;
  key_event.shift = (event.modifiers & EVENTFLAG_SHIFT_DOWN) != 0;
  key_event.alt = (event.modifiers & EVENTFLAG_ALT_DOWN) != 0;

  engine::KeyContext key_context;
  key_context.is_devtools_browser = IsDevToolsBrowser(browser);
  key_context.is_content_browser = IsContentBrowser(browser);
  key_context.content_visible = content_visible_;

  switch (engine::ResolveKeyAction(key_event, key_context)) {
    case engine::KeyAction::ToggleDevTools:
      ToggleDevTools();
      return true;
    case engine::KeyAction::FocusAddressBar:
      if (shell_browser_view_) {
        shell_browser_view_->RequestFocus();
        if (auto b = shell_browser_view_->GetBrowser()) {
          b->GetHost()->SetFocus(true);
        }
      }
      EmitBrowserEvent(Json{{"type", "focus-address-bar"}});
      return true;
    case engine::KeyAction::ToggleFindBar:
      ToggleFindBar();
      return true;
    case engine::KeyAction::ReloadPage:
      ContentReload(false);
      return true;
    case engine::KeyAction::ReloadPageIgnoringCache:
      ContentReload(true);
      return true;
    case engine::KeyAction::None:
      break;
  }
  return false;
}

void MeshHandler::ToggleDevTools() {
  CEF_REQUIRE_UI_THREAD();
  // MenuButton::ExecuteCommand runs while the native menu is still tearing
  // down. Creating a top-level window in that stack can close the host.
  CefPostTask(TID_UI, base::BindOnce([]() {
                if (auto* self = MeshHandler::GetInstance()) {
                  self->ShowDevToolsNow();
                }
              }));
}

void MeshHandler::ShowDevToolsNow() {
  CEF_REQUIRE_UI_THREAD();
  CefRefPtr<CefBrowser> browser;
  if (content_visible_) {
    browser = ContentBrowser();
  }
  if (!browser && shell_browser_view_) {
    browser = shell_browser_view_->GetBrowser();
  }
  if (!browser) {
    return;
  }
  auto host = browser->GetHost();
  if (!host) {
    return;
  }
  if (host->HasDevTools()) {
    host->CloseDevTools();
    return;
  }
  CefWindowInfo window_info;
#if defined(OS_WIN)
  window_info.SetAsPopup(nullptr, "DevTools");
#endif
  window_info.runtime_style = CEF_RUNTIME_STYLE_CHROME;
  CefBrowserSettings settings;
  host->ShowDevTools(window_info, this, settings, CefPoint());
}

void MeshHandler::ContentStop() {
  CEF_REQUIRE_UI_THREAD();
  auto browser = ContentBrowser();
  if (browser) {
    SafeStopLoad(browser);
  }
}

void MeshHandler::ContentClear() {
  CEF_REQUIRE_UI_THREAD();
  auto browser = ContentBrowser();
  if (!browser) {
    return;
  }
  SafeStopLoad(browser);
  ClearContentSeedIdle(browser);
  // Only wipe the active tab document; background tabs keep their media.
  if (auto frame = browser->GetMainFrame()) {
    frame->LoadURL("about:blank");
  }
}

void MeshHandler::SetContentVisible(bool visible) {
  CEF_REQUIRE_UI_THREAD();
  content_visible_ = visible && ActiveContentView() != nullptr;
  LayoutContentBrowser();
  EmitBrowserEvent(Json{{"type", "visibility"},
                        {"visible", content_visible_},
                        {"tabId", active_tab_id_}});
}

void MeshHandler::SetChromeHeight(int height) {
  CEF_REQUIRE_UI_THREAD();
  // The chrome strip is just the titlebar row; clamping it upwards leaves a
  // gap between the titlebar and the content pane.
  if (height < 1) {
    height = 1;
  }
  if (height == chrome_height_) {
    return;
  }
  chrome_height_ = height;
  LayoutContentBrowser();
}

void MeshHandler::LayoutContentBrowser() {
  CEF_REQUIRE_UI_THREAD();
  if (!shell_browser_view_) {
    return;
  }
  auto window = shell_browser_view_->GetWindow();
  if (!window) {
    return;
  }

  CefRefPtr<CefBoxLayout> box;
  if (auto layout = window->GetLayout()) {
    box = layout->AsBoxLayout();
  }

  const bool show_content = content_visible_ && !active_tab_id_.empty() &&
                            ContentViewForTab(active_tab_id_) != nullptr;

  for (const auto& recycled : recycled_content_views_) {
    if (recycled) {
      recycled->SetVisible(false);
      if (box) {
        box->SetFlexForView(recycled, 0);
      }
    }
  }

  for (const auto& entry : tab_content_views_) {
    const bool show = show_content && entry.first == active_tab_id_;
    if (entry.second) {
      entry.second->SetVisible(show);
      if (box) {
        box->SetFlexForView(entry.second, show ? 1 : 0);
      }
      entry.second->InvalidateLayout();
    }
  }

  if (box) {
    if (show_content) {
      box->SetFlexForView(shell_browser_view_, 0);
    } else {
      box->SetFlexForView(shell_browser_view_, 1);
    }
  }

  if (devtools_browser_view_) {
    const bool show_dt = devtools_docked_ && show_content;
    devtools_browser_view_->SetVisible(show_dt);
    if (box) {
      box->SetFlexForView(devtools_browser_view_, show_dt ? 1 : 0);
    }
    devtools_browser_view_->InvalidateLayout();
  }

  shell_browser_view_->InvalidateLayout();
  window->InvalidateLayout();
  LayoutAiHud();
}

void MeshHandler::ApplyOverlayBounds(int height) {
  if (!overlay_controller_) {
    return;
  }

  int win_w = 0;
  int win_h = 0;
  if (shell_browser_view_) {
    if (auto window = shell_browser_view_->GetWindow()) {
      const CefRect bounds = window->GetBounds();
      win_w = bounds.width;
      win_h = bounds.height;
    }
  }

  int h = height;
  if (win_h > 40) {
    const int max_height = win_h - overlay_anchor_top_ - 8;
    if (max_height > 40 && h > max_height) {
      h = max_height;
    }
  }
  if (h < 40) {
    h = 40;
  }

  int x = overlay_anchor_right_ - overlay_width_;
  int y = overlay_anchor_top_;
  constexpr int kPad = 8;
  if (x < kPad) {
    x = kPad;
  }
  if (win_w > 0 && x + overlay_width_ > win_w - kPad) {
    x = win_w - overlay_width_ - kPad;
    if (x < kPad) {
      x = kPad;
    }
  }
  if (win_h > 0 && y + h > win_h - kPad) {
    y = win_h - h - kPad;
    if (y < 0) {
      y = 0;
    }
  }

  overlay_height_ = h;
  overlay_controller_->SetBounds(CefRect(x, y, overlay_width_, h));
}

void MeshHandler::EnsureAppMenuButton() {
  if (app_menu_button_ || !shell_browser_view_) {
    return;
  }
  auto window = shell_browser_view_->GetWindow();
  if (!window) {
    return;
  }

  app_menu_button_host_ = new AppMenuButtonHost();
  app_menu_button_ =
      CefMenuButton::CreateMenuButton(app_menu_button_host_, "");
  if (!app_menu_button_) {
    app_menu_button_host_ = nullptr;
    return;
  }
  app_menu_button_->SetFocusable(false);

  // Invisible 1x1 host — only needed so ShowMenu uses the MenuButton path
  // (HAS_MNEMONICS) like Chrome/Brave, not Window::ShowMenu (CONTEXT_MENU).
  app_menu_button_controller_ = window->AddOverlayView(
      app_menu_button_, CEF_DOCKING_MODE_CUSTOM, /*can_activate=*/false);
  if (app_menu_button_controller_) {
    app_menu_button_controller_->SetBounds(CefRect(0, 0, 1, 1));
    app_menu_button_controller_->SetVisible(false);
  }
}

void MeshHandler::ShowAppMenu(int anchor_left,
                              int anchor_top,
                              int anchor_right,
                              int anchor_bottom,
                              const Json& payload) {
  CEF_REQUIRE_UI_THREAD();
  if (!shell_browser_view_) {
    return;
  }
  if (!shell_browser_view_->GetWindow()) {
    return;
  }

  // Cancel any previous menu so CEF never stays in a stale menu-running state
  if (auto window = shell_browser_view_->GetWindow()) {
    window->CancelMenu();
  }
  OverlayHide();
  app_menu_open_ = false;
  app_menu_ = nullptr;

  app_menu_ = new AppMenuDelegate(this, payload);
  CefRefPtr<CefMenuModel> model = app_menu_->Build();
  if (!model) {
    app_menu_ = nullptr;
    return;
  }

  EnsureAppMenuButton();
  if (!app_menu_button_) {
    app_menu_ = nullptr;
    return;
  }

  // Brave/Chrome AppMenu::RunMenu:
  //   RunMenuAt(widget, host, button->GetAnchorBoundsInScreen(), kTopRight)
  // CEF only accepts a point; bottom-right of the button + TOPRIGHT is the
  // same math (menu.right = button.right, menu.top = button.bottom).
  // The engine owns the anchoring rule; the product supplies the raw rect.
  const engine::AppMenuAnchor anchor = engine::NormalizeAppMenuAnchor(
      anchor_left, anchor_top, anchor_right, anchor_bottom);
  const int right = anchor.x();
  const int bottom = anchor.y();

  app_menu_btn_right_ = right;
  app_menu_btn_bottom_ = bottom;

  if (app_menu_button_controller_) {
    app_menu_button_controller_->SetBounds(CefRect(0, 0, 1, 1));
    app_menu_button_controller_->SetVisible(true);
  }

  CefPoint screen_point(right, bottom);
  if (!shell_browser_view_->ConvertPointToScreen(screen_point)) {
    const CefRect shell = shell_browser_view_->GetBoundsInScreen();
    screen_point.x = shell.x + right;
    screen_point.y = shell.y + bottom;
  }

  app_menu_open_ = true;
#if defined(_WIN32)
  ApplyImmersiveMenuAppearance();
  HWND main_hwnd = nullptr;
  if (shell_browser_view_) {
    if (auto window = shell_browser_view_->GetWindow()) {
      main_hwnd = window->GetWindowHandle();
    }
  }
  // The engine tracks the native menu window (where it is anchored, when it
  // is dismissed); the product supplies the native styling and reacts to
  // the dismissal.
  engine::NativeMenuTracker::Callbacks tracker_callbacks;
  tracker_callbacks.on_popup_created = [](void* native_window) {
    ApplyNativeMenuAppearance(static_cast<HWND>(native_window));
  };
  tracker_callbacks.on_menu_closed = [this]() {
    if (app_menu_open_) {
      OnAppMenuClosed();
    }
  };
  tracker_callbacks.is_foreign_window = [](void* native_window) {
    HWND hwnd = static_cast<HWND>(native_window);
    wchar_t cls[64] = {};
    if (GetClassNameW(hwnd, cls, 64) <= 0) {
      return false;
    }
    // The AI HUD overlay is a product window, not a menu popup.
    return wcscmp(cls, L"MeshAiHud") == 0;
  };
  tracker_callbacks.log = [](const std::string& message) {
    mesh::Log(message);
  };
  engine::NativeMenuTracker::Get().Install(main_hwnd, tracker_callbacks);
#endif
  // Must go through MenuButton::ShowMenu (not Window::ShowMenu) so CEF uses
  // HAS_MNEMONICS instead of CONTEXT_MENU — otherwise Windows flips the menu
  // open to the right past the window edge.
  app_menu_button_->ShowMenu(model, screen_point, CEF_MENU_ANCHOR_TOPRIGHT);
}

void MeshHandler::CancelAppMenu() {
  CEF_REQUIRE_UI_THREAD();
  if (!app_menu_open_ || !shell_browser_view_) {
    return;
  }
  if (auto window = shell_browser_view_->GetWindow()) {
    window->CancelMenu();
  }
}

void MeshHandler::OnAppMenuClosed() {
  CEF_REQUIRE_UI_THREAD();
  app_menu_open_ = false;
  app_menu_ = nullptr;
  engine::NativeMenuTracker::Get().Remove();
  if (app_menu_button_controller_) {
    app_menu_button_controller_->SetBounds(CefRect(0, 0, 1, 1));
    app_menu_button_controller_->SetVisible(false);
  }
  EmitBrowserEvent(Json{{"type", "menu"}, {"visible", false}});
}

void MeshHandler::EmitMenuCommand(const Json& command) {
  CEF_REQUIRE_UI_THREAD();
  EmitBrowserEvent(Json{{"type", "menu-command"}, {"command", command}});
}

namespace {

int64_t NowMs() {
  return static_cast<int64_t>(
      std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::system_clock::now().time_since_epoch())
          .count());
}

std::string DownloadState(CefRefPtr<CefDownloadItem> item) {
  if (!item || !item->IsValid()) {
    return "interrupted";
  }
  if (item->IsComplete()) {
    return "complete";
  }
  if (item->IsCanceled()) {
    return "canceled";
  }
  if (item->IsInterrupted()) {
    return "interrupted";
  }
  if (item->IsInProgress()) {
    return "in_progress";
  }
  return "interrupted";
}

Json DownloadEntryFromItem(CefRefPtr<CefDownloadItem> item,
                           const std::string& suggested_name) {
  Json entry = Json::object();
  if (!item || !item->IsValid()) {
    return entry;
  }
  const std::string id = std::to_string(item->GetId());
  std::string path = item->GetFullPath().ToString();
  std::string filename = suggested_name;
  if (filename.empty()) {
    filename = item->GetSuggestedFileName().ToString();
  }
  if (filename.empty() && !path.empty()) {
    filename = utf8::Narrow(
        std::filesystem::path(utf8::Widen(path)).filename().wstring());
  }
  if (filename.empty()) {
    filename = "download";
  }
  entry = Json{{"id", id},
               {"url", item->GetURL().ToString()},
               {"originalUrl", item->GetOriginalUrl().ToString()},
               {"path", path},
               {"filename", filename},
               {"mime", item->GetMimeType().ToString()},
               {"state", DownloadState(item)},
               {"receivedBytes", item->GetReceivedBytes()},
               {"totalBytes", item->GetTotalBytes()},
               {"percent", item->GetPercentComplete()},
               {"ts", NowMs()}};
  return entry;
}

}  // namespace

bool MeshHandler::OnBeforeDownload(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefDownloadItem> download_item,
    const CefString& suggested_name,
    CefRefPtr<CefBeforeDownloadCallback> callback) {
  CEF_REQUIRE_UI_THREAD();
  (void)browser;
  if (!callback) {
    return false;
  }

  std::string name = suggested_name.ToString();
  if (name.empty() && download_item && download_item->IsValid()) {
    name = download_item->GetSuggestedFileName().ToString();
  }
  if (name.empty()) {
    name = "download";
  }

  // The engine owns the file-name rule; the product owns the download store.
  name = engine::SanitizeDownloadFileName(name);

  const std::string dir = paths::EnsureUserDownloadsDir();
  const std::string full =
      utf8::Narrow((std::filesystem::path(utf8::Widen(dir)) /
                    std::filesystem::path(utf8::Widen(name)))
                       .wstring());

  callback->Continue(full, false);

  Json entry = DownloadEntryFromItem(download_item, name);
  if (!entry.empty()) {
    entry["path"] = full;
    entry["filename"] = name;
    entry["state"] = "in_progress";
    if (entry.value("ts", 0LL) <= 0) {
      entry["ts"] = NowMs();
    }
    downloads::Upsert(entry);
    EmitDownloadProgress();
  }
  return true;
}

void MeshHandler::OnDownloadUpdated(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefDownloadItem> download_item,
    CefRefPtr<CefDownloadItemCallback> callback) {
  CEF_REQUIRE_UI_THREAD();
  (void)browser;
  (void)callback;
  if (!download_item || !download_item->IsValid()) {
    return;
  }
  Json entry = DownloadEntryFromItem(download_item, "");
  if (entry.empty()) {
    return;
  }
  // Preserve the original start timestamp when updating progress.
  const Json existing = downloads::List();
  const std::string id = entry.value("id", std::string());
  for (const auto& prev : existing) {
    if (prev.value("id", std::string()) == id) {
      const int64_t ts = prev.value("ts", 0LL);
      if (ts > 0) {
        entry["ts"] = ts;
      }
      break;
    }
  }
  downloads::Upsert(entry);
  EmitDownloadProgress();
}

void MeshHandler::EmitDownloadProgress() {
  CEF_REQUIRE_UI_THREAD();
  const Json list = downloads::List();
  int active = 0;
  int64_t received = 0;
  int64_t total = 0;
  int percent_sum = 0;
  int percent_n = 0;
  for (const auto& entry : list) {
    if (!entry.is_object()) {
      continue;
    }
    if (entry.value("state", std::string()) != "in_progress") {
      continue;
    }
    active += 1;
    received += entry.value("receivedBytes", 0LL);
    total += entry.value("totalBytes", 0LL);
    const int pct = entry.value("percent", -1);
    if (pct >= 0) {
      percent_sum += pct;
      percent_n += 1;
    }
  }
  int percent = 0;
  if (percent_n > 0) {
    percent = percent_sum / percent_n;
  } else if (total > 0) {
    percent = static_cast<int>((received * 100) / total);
  }
  if (percent < 0) {
    percent = 0;
  }
  if (percent > 100) {
    percent = 100;
  }
  EmitBrowserEvent(Json{{"type", "download"},
                        {"active", active},
                        {"percent", percent},
                        {"receivedBytes", received},
                        {"totalBytes", total}});
}

void MeshHandler::ShowHistoryFlyout(const Json& recent_tabs) {
  CEF_REQUIRE_UI_THREAD();
  // Main menu is TOPRIGHT under the button. Place the favicon flyout at the
  // menu's left edge, aligned with the History row (Brave cascade position).
  constexpr int kMainMenuW = 248;
  constexpr int kRow = 30;
  constexpr int kSep = 9;
  constexpr int kPadY = 4;
  const int flyout_right =
      std::max(8, app_menu_btn_right_ - kMainMenuW);
  const int flyout_top = app_menu_btn_bottom_ + kPadY + 3 * kRow + kSep;

  Json items = Json::array();
  items.push_back(Json{{"type", "action"},
                       {"title", "Open history page"},
                       {"action", "open-history"},
                       {"shortcut", "Ctrl+H"}});
  if (recent_tabs.is_array() && !recent_tabs.empty()) {
    items.push_back(Json{{"type", "separator"}});
    for (const auto& entry : recent_tabs) {
      items.push_back(entry);
    }
  }

  history_flyout_visible_ = true;
  OverlayShow(flyout_right, flyout_top, 300, 0,
              Json{{"view", "history"}, {"items", std::move(items)}});
}

void MeshHandler::HideHistoryFlyout() {
  CEF_REQUIRE_UI_THREAD();
  if (!history_flyout_visible_) {
    return;
  }
  history_flyout_visible_ = false;
  OverlayHide();
}

void MeshHandler::HandleOverlayCommand(const Json& command) {
  CEF_REQUIRE_UI_THREAD();
  history_flyout_visible_ = false;
  CancelAppMenu();
  OverlayHide();
  EmitMenuCommand(command);
}

void MeshHandler::ForceCloseAuxiliaryBrowsers() {
  std::vector<CefRefPtr<CefBrowserView>> views;
  views.reserve(tab_content_views_.size() + 1);
  for (const auto& entry : tab_content_views_) {
    if (entry.second) {
      views.push_back(entry.second);
    }
  }
  for (const auto& recycled : recycled_content_views_) {
    if (recycled) {
      views.push_back(recycled);
    }
  }
  recycled_content_views_.clear();
  active_tab_id_.clear();
  content_visible_ = false;
  tab_audio_playing_.clear();
  tab_media_.clear();
  tab_titles_.clear();
  pending_content_urls_.clear();
  content_seed_idle_ids_.clear();
  recycling_content_browser_ids_.clear();

  if (shell_browser_view_) {
    if (auto shell = shell_browser_view_->GetBrowser()) {
      if (auto host = shell->GetHost()) {
        if (host->HasDevTools()) {
          host->CloseDevTools();
        }
      }
    }
  }
  for (const auto& view : views) {
    if (auto content = view->GetBrowser()) {
      if (auto host = content->GetHost()) {
        if (host->HasDevTools()) {
          host->CloseDevTools();
        }
        host->CloseBrowser(true);
      }
    }
  }
  if (overlay_browser_view_) {
    if (auto overlay = overlay_browser_view_->GetBrowser()) {
      overlay->GetHost()->CloseBrowser(true);
    }
  }

  std::vector<CefRefPtr<CefBrowser>> extras;
  extras.reserve(browsers_.size());
  for (const auto& extra : browsers_) {
    if (extra && !IsShellBrowser(extra) && !IsContentBrowser(extra) &&
        !IsOverlayBrowser(extra)) {
      extras.push_back(extra);
    }
  }
  for (const auto& extra : extras) {
    if (auto host = extra->GetHost()) {
      host->CloseBrowser(true);
    }
  }
}

// ---- engine::EngineWindowHooks ------------------------------------------
// The engine owns the native window (composition, layout, close sequencing).
// These hooks are where the product contributes its own window chrome and
// the overlays it owns.

void MeshHandler::OnEngineApplyWindowAppearance(CefRefPtr<CefWindow> window) {
#if defined(OS_WIN)
  ApplyAppIcon(window);
  HWND hwnd = window ? window->GetWindowHandle() : nullptr;
  ApplyNativeWindowAppearance(hwnd);
  ApplyImmersiveMenuAppearance();
  InstallSystemAppearanceListener(hwnd);
#else
  (void)window;
#endif
}

void MeshHandler::OnEngineApplyContentTheme() {
  ApplyChromeAppearance();
}

void MeshHandler::OnEngineWindowClosing() {
  BeginShutdown();
}

void MeshHandler::OnEngineDestroyProductOverlays() {
  DestroyAiHud();
}

void MeshHandler::OnEngineLayoutProductOverlays() {
  LayoutAiHud();
}

void MeshHandler::BeginShutdown() {
  CEF_REQUIRE_UI_THREAD();
  if (shutting_down_) {
    return;
  }
  shutting_down_ = true;
  closing_ = true;

  DestroyAiHud();

  McpServer::Get().Shutdown();
  FailPendingAgentQueries("Browser is shutting down");

  CancelAppMenu();
  OverlayHide();
  ForceCloseAuxiliaryBrowsers();

  // If a child browser stalls OnBeforeClose, still leave the message loop so
  // CefShutdown can tear down GPU/renderer processes.
  CefPostDelayedTask(TID_UI, base::BindOnce([]() {
                       if (auto* self = MeshHandler::GetInstance()) {
                         self->FinishShutdown();
                       }
                     }),
                     250);
}

void MeshHandler::FinishShutdown() {
  CEF_REQUIRE_UI_THREAD();
  if (quit_posted_) {
    return;
  }
  quit_posted_ = true;

  ForceCloseAuxiliaryBrowsers();
  hot_reload_.Stop();
  terminals_.CloseAll();
  browser_subscribers_.clear();
  overlay_subscribers_.clear();
  if (message_router_ && library_handler_) {
    message_router_->RemoveHandler(library_handler_);
    delete library_handler_;
    library_handler_ = nullptr;
  }
  message_router_ = nullptr;
  app_menu_button_controller_ = nullptr;
  app_menu_button_ = nullptr;
  app_menu_button_host_ = nullptr;

  if (auto cookies = CefCookieManager::GetGlobalManager(nullptr)) {
    cookies->FlushStore(nullptr);
  }

  CefQuitMessageLoop();
}

void MeshHandler::OverlayShow(int anchor_right,
                              int anchor_top,
                              int width,
                              int height,
                              const Json& payload) {
  CEF_REQUIRE_UI_THREAD();
  if (!overlay_controller_) {
    return;
  }
  // History flyout rides next to the open native menu — do not dismiss it.
  const bool keep_menu =
      payload.is_object() && payload.value("view", "") == "history";
  if (!keep_menu) {
    CancelAppMenu();
  }
  overlay_anchor_right_ = anchor_right;
  overlay_anchor_top_ = anchor_top;
  if (width > 0) {
    overlay_width_ = width;
  }
  if (!overlay_visible_) {
    ApplyOverlayBounds(height > 0 ? height : 120);
    overlay_controller_->SetVisible(true);
    overlay_visible_ = true;
  } else if (height > 0) {
    // Explicit size (menu open / tip first layout) — apply it.
    ApplyOverlayBounds(height);
  } else {
    // height<=0: content-only refresh (tip memory poll). Keep size so the
    // overlay doesn't pulse between the placeholder and measured height.
    ApplyOverlayBounds(overlay_height_ > 0 ? overlay_height_ : 120);
  }
  const std::string view_type =
      payload.is_object() ? payload.value("view", "") : "";
  active_overlay_view_ = view_type;

#if defined(OS_WIN)
  if (overlay_browser_view_) {
    if (auto browser = overlay_browser_view_->GetBrowser()) {
      if (auto host = browser->GetHost()) {
        HWND hwnd = host->GetWindowHandle();
        if (hwnd) {
          ::BringWindowToTop(hwnd);
          ::SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0,
                         SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW | SWP_NOACTIVATE);
        }
      }
    }
  }
#endif
  EmitOverlayEvent(Json{{"type", "show"}, {"payload", payload}});
}

void MeshHandler::OverlayResize(int width, int height) {
  CEF_REQUIRE_UI_THREAD();
  if (!overlay_controller_ || !overlay_visible_) {
    return;
  }
  if (width > 0) {
    overlay_width_ = width;
  }
  ApplyOverlayBounds(height);
}

void MeshHandler::OverlayHide() {
  CEF_REQUIRE_UI_THREAD();
  active_overlay_view_.clear();
  if (!overlay_visible_) {
    return;
  }
  overlay_visible_ = false;
  if (overlay_controller_) {
    overlay_controller_->SetVisible(false);
  }
  EmitOverlayEvent(Json{{"type", "hide"}});
  EmitBrowserEvent(Json{{"type", "overlay"}, {"visible", false}});
}

namespace {
constexpr const char* kInPageFindBarScript = R"JS(
(() => {
  function clearAllHighlights() {
    try {
      const marks = document.querySelectorAll('mark.mesh-match');
      marks.forEach(m => {
        const parent = m.parentNode;
        if (parent) {
          parent.replaceChild(document.createTextNode(m.textContent), m);
          parent.normalize();
        }
      });
    } catch(e) {}
  }

  let host = document.getElementById('mesh-find-host');
  if (host) {
    host.remove();
    clearAllHighlights();
    return;
  }

  host = document.createElement('div');
  host.id = 'mesh-find-host';
  host.style.cssText = 'position:fixed;top:14px;right:22px;z-index:2147483647;pointer-events:auto;line-height:normal;';
  const shadow = host.attachShadow({mode: 'open'});
  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      :host { all: initial; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
      .find-pill {
        display: flex;
        align-items: center;
        gap: 6px;
        height: 38px;
        padding: 4px 6px 4px 10px;
        background: rgba(26, 25, 26, 0.94);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 20px;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.45);
        color: #e4e4e4;
        user-select: none;
        animation: meshFindIn 140ms cubic-bezier(0.16, 1, 0.3, 1);
      }
      @keyframes meshFindIn {
        from { opacity: 0; transform: translateY(-6px) scale(0.97); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }
      @media (prefers-color-scheme: light) {
        .find-pill {
          background: rgba(255, 255, 255, 0.96);
          border: 1px solid rgba(0, 0, 0, 0.16);
          color: #1a191a;
          box-shadow: 0 6px 24px rgba(0, 0, 0, 0.16);
        }
        .find-input {
          background: rgba(0, 0, 0, 0.05) !important;
          border-color: rgba(0, 0, 0, 0.12) !important;
          color: #1a191a !important;
        }
        .find-input::placeholder {
          color: #888888 !important;
        }
        .find-count {
          color: #6a696a !important;
          background: rgba(0, 0, 0, 0.05) !important;
        }
        .find-btn {
          color: #6a696a !important;
        }
        .find-btn:hover {
          background: rgba(0, 0, 0, 0.08) !important;
          color: #1a191a !important;
        }
      }
      .find-input {
        width: 155px;
        height: 28px;
        line-height: 26px;
        padding: 0 10px;
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.14);
        border-radius: 14px;
        color: #ffffff;
        font-family: inherit;
        font-size: 13px;
        outline: none;
        box-sizing: border-box;
        vertical-align: middle;
      }
      .find-input::placeholder {
        color: #888888;
        line-height: 26px;
      }
      .find-input:focus {
        border-color: #66c0f4;
        box-shadow: 0 0 0 2px rgba(102, 192, 244, 0.25);
      }
      .find-count {
        font-size: 11px;
        color: #8a8a8a;
        padding: 2px 8px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.06);
        font-variant-numeric: tabular-nums;
        white-space: nowrap;
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 22px;
      }
      .find-count.has-matches {
        color: #66c0f4;
        font-weight: 600;
        background: rgba(102, 192, 244, 0.16);
      }
      .find-btn {
        width: 26px;
        height: 26px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        border: none;
        background: transparent;
        color: #8a8a8a;
        cursor: pointer;
        padding: 0;
        flex-shrink: 0;
        transition: background 100ms ease, color 100ms ease;
      }
      .find-btn svg {
        display: block;
        pointer-events: none;
      }
      .find-btn:hover {
        background: rgba(255, 255, 255, 0.12);
        color: #ffffff;
      }
    </style>
    <div class="find-pill">
      <input class="find-input" type="text" placeholder="Find in page..." autocomplete="off" spellcheck="false" />
      <span class="find-count">0/0</span>
      <button class="find-btn" id="find-prev" title="Previous (Shift+Enter)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg></button>
      <button class="find-btn" id="find-next" title="Next (Enter)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg></button>
      <button class="find-btn" id="find-close" title="Close (Escape)"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>
    </div>
  `;
  (document.body || document.documentElement).appendChild(host);
  const input = shadow.querySelector('.find-input');
  const count = shadow.querySelector('.find-count');
  const prevBtn = shadow.getElementById('find-prev');
  const nextBtn = shadow.getElementById('find-next');
  const closeBtn = shadow.getElementById('find-close');

  let totalMatches = 0;
  let currentIndex = 0;

  function updateDisplay() {
    if (!input.value) {
      count.textContent = "0/0";
      count.classList.remove("has-matches");
      return;
    }
    if (totalMatches > 0) {
      count.textContent = `${currentIndex}/${totalMatches}`;
      count.classList.add("has-matches");
    } else {
      count.textContent = "0/0";
      count.classList.remove("has-matches");
    }
  }

  function setActiveMark(index, scroll) {
    const allMarks = document.querySelectorAll('mark.mesh-match');
    allMarks.forEach((m, i) => {
      if (i === index) {
        m.style.cssText = 'background-color:#ff9800!important;color:#1a191a!important;outline:2px solid #e65100!important;border-radius:2px!important;padding:0 1px!important;';
        if (scroll) {
          try { m.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch(e) {}
        }
      } else {
        m.style.cssText = 'background-color:#ffe066!important;color:#1a191a!important;border-radius:2px!important;padding:0 1px!important;';
      }
    });
  }

  function performHighlight(query) {
    clearAllHighlights();
    const q = (query || "").trim().toLowerCase();
    if (!q) {
      totalMatches = 0;
      currentIndex = 0;
      updateDisplay();
      return;
    }

    try {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const textNodes = [];
      let node;
      while ((node = walker.nextNode())) {
        if (!node.nodeValue) continue;
        const p = node.parentElement;
        if (p && (p.tagName === "SCRIPT" || p.tagName === "STYLE" || p.tagName === "NOSCRIPT" || p.closest('#mesh-find-host'))) continue;
        if (node.nodeValue.toLowerCase().includes(q)) {
          textNodes.push(node);
        }
      }

      for (const n of textNodes) {
        const text = n.nodeValue;
        let idx = text.toLowerCase().indexOf(q);
        if (idx === -1) continue;

        const frag = document.createDocumentFragment();
        let lastIdx = 0;
        while (idx !== -1) {
          if (idx > lastIdx) {
            frag.appendChild(document.createTextNode(text.substring(lastIdx, idx)));
          }
          const mark = document.createElement('mark');
          mark.className = 'mesh-match';
          mark.style.cssText = 'background-color:#ffe066!important;color:#1a191a!important;border-radius:2px!important;padding:0 1px!important;';
          mark.textContent = text.substring(idx, idx + query.trim().length);
          frag.appendChild(mark);

          lastIdx = idx + query.trim().length;
          idx = text.toLowerCase().indexOf(q, lastIdx);
        }
        if (lastIdx < text.length) {
          frag.appendChild(document.createTextNode(text.substring(lastIdx)));
        }
        if (n.parentNode) {
          n.parentNode.replaceChild(frag, n);
        }
      }
    } catch(e) {}

    const allMarks = document.querySelectorAll('mark.mesh-match');
    totalMatches = allMarks.length;
    if (totalMatches > 0) {
      currentIndex = 1;
      setActiveMark(0, true);
    } else {
      currentIndex = 0;
    }
    updateDisplay();
  }

  function cycleMatch(backwards) {
    if (totalMatches <= 0) return;
    if (backwards) {
      currentIndex = currentIndex <= 1 ? totalMatches : currentIndex - 1;
    } else {
      currentIndex = currentIndex >= totalMatches ? 1 : currentIndex + 1;
    }
    setActiveMark(currentIndex - 1, true);
    updateDisplay();
  }

  function closeFind() {
    clearAllHighlights();
    host.remove();
  }

  input.addEventListener('input', () => {
    performHighlight(input.value);
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      cycleMatch(e.shiftKey);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      closeFind();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      closeFind();
    }
  });

  prevBtn.addEventListener('click', () => cycleMatch(true));
  nextBtn.addEventListener('click', () => cycleMatch(false));
  closeBtn.addEventListener('click', closeFind);

  setTimeout(() => {
    input.focus();
  }, 25);
})();
)JS";

constexpr const char* kHideFindBarScript = R"JS(
(() => {
  let host = document.getElementById('mesh-find-host');
  if (host) {
    host.remove();
  }
  try {
    const marks = document.querySelectorAll('mark.mesh-match');
    marks.forEach(m => {
      const parent = m.parentNode;
      if (parent) {
        parent.replaceChild(document.createTextNode(m.textContent), m);
        parent.normalize();
      }
    });
  } catch(e) {}
})();
)JS";
}  // namespace

void MeshHandler::ToggleFindBar() {
  CEF_REQUIRE_UI_THREAD();
  CefRefPtr<CefBrowser> browser;
  if (content_visible_) {
    if (auto view = content_browser_view()) {
      browser = view->GetBrowser();
    }
  } else if (shell_browser_view_) {
    browser = shell_browser_view_->GetBrowser();
  }
  if (!browser) {
    return;
  }
  auto frame = browser->GetMainFrame();
  if (!frame) {
    return;
  }
  frame->ExecuteJavaScript(kInPageFindBarScript, frame->GetURL(), 0);
}

void MeshHandler::ShowFindBar() {
  CEF_REQUIRE_UI_THREAD();
  CefRefPtr<CefBrowser> browser;
  if (content_visible_) {
    if (auto view = content_browser_view()) {
      browser = view->GetBrowser();
    }
  } else if (shell_browser_view_) {
    browser = shell_browser_view_->GetBrowser();
  }
  if (!browser) {
    return;
  }
  auto frame = browser->GetMainFrame();
  if (!frame) {
    return;
  }
  frame->ExecuteJavaScript(kInPageFindBarScript, frame->GetURL(), 0);
}

void MeshHandler::HideFindBar() {
  CEF_REQUIRE_UI_THREAD();
  CefRefPtr<CefBrowser> browser;
  if (content_visible_) {
    if (auto view = content_browser_view()) {
      browser = view->GetBrowser();
    }
  } else if (shell_browser_view_) {
    browser = shell_browser_view_->GetBrowser();
  }
  if (!browser) {
    return;
  }
  auto frame = browser->GetMainFrame();
  if (!frame) {
    return;
  }
  frame->ExecuteJavaScript(kHideFindBarScript, frame->GetURL(), 0);
}

void MeshHandler::SetAiActive(bool active, int agent_count) {
  CEF_REQUIRE_UI_THREAD();
#if defined(OS_WIN)
  constexpr bool native_hud = true;
#else
  constexpr bool native_hud = false;
#endif
  ai_active_ = active;
  ai_paused_ = false;
  ai_agent_count_ = active ? std::max(1, agent_count) : 0;
  EmitBrowserEvent(Json{
      {"type", "ai.active"},
      {"active", active},
      {"paused", false},
      {"nativeHud", native_hud},
      {"agentCount", ai_agent_count_},
  });
  LayoutAiHud();
  if (active) {
    CefPostDelayedTask(TID_UI, base::BindOnce([]() {
                         if (auto* handler = MeshHandler::GetInstance()) {
                           handler->LayoutAiHud();
                         }
                       }),
                       64);
  }
}

void MeshHandler::SetAiPaused(bool paused) {
  CEF_REQUIRE_UI_THREAD();
#if defined(OS_WIN)
  constexpr bool native_hud = true;
#else
  constexpr bool native_hud = false;
#endif
  ai_paused_ = paused;
  ai_active_ = paused;
  ai_agent_count_ = 0;
  EmitBrowserEvent(Json{
      {"type", "ai.active"},
      {"active", paused},
      {"paused", paused},
      {"nativeHud", native_hud},
      {"agentCount", 0},
  });
  LayoutAiHud();
}

void MeshHandler::LayoutAiHud() {
  CEF_REQUIRE_UI_THREAD();
#if defined(OS_WIN)
  HWND parent = nullptr;
  if (shell_browser_view_) {
    if (auto window = shell_browser_view_->GetWindow()) {
      parent = window->GetWindowHandle();
    }
  }
  if (!parent) {
    if (ai_hud_) {
      ai_hud_->Detach();
    }
    return;
  }
  if (!ai_hud_) {
    ai_hud_ = std::make_unique<AiHudOverlay>();
  }
  ai_hud_->Attach(parent);
  ai_hud_->SetActive(ai_active_, ai_agent_count_);
  ai_hud_->SetPaused(ai_paused_);
  ai_hud_->Layout(chrome_height_);
#endif
}

void MeshHandler::DestroyAiHud() {
  if (ai_hud_) {
    ai_hud_->Detach();
    ai_hud_.reset();
  }
}

void MeshHandler::MoveAgentPointer(float css_x, float css_y, bool click) {
  CEF_REQUIRE_UI_THREAD();
  LayoutAiHud();
  float scale = 1.0f;
#if defined(OS_WIN)
  if (shell_browser_view_) {
    if (auto window = shell_browser_view_->GetWindow()) {
      HWND hwnd = window->GetWindowHandle();
      if (hwnd) {
        UINT dpi = GetDpiForWindow(hwnd);
        if (dpi > 0) {
          scale = static_cast<float>(dpi) / 96.0f;
        }
      }
    }
  }
#endif
  if (ai_hud_) {
    ai_hud_->MovePointer(css_x * scale, css_y * scale, click);
  }
}

void MeshHandler::SendAgentMouseClick(int css_x, int css_y) {
  CEF_REQUIRE_UI_THREAD();
  auto view = ActiveContentView();
  if (!view) {
    return;
  }
  auto browser = view->GetBrowser();
  if (!browser) {
    return;
  }
  auto host = browser->GetHost();
  if (!host) {
    return;
  }
  CefMouseEvent ev;
  ev.x = css_x;
  ev.y = css_y;
  host->SendMouseMoveEvent(ev, false);
  host->SendMouseClickEvent(ev, MBT_LEFT, false, 1);
  host->SendMouseClickEvent(ev, MBT_LEFT, true, 1);
}

void MeshHandler::SubscribeOverlayEvents(
    int64_t query_id,
    CefRefPtr<CefMessageRouterBrowserSide::Callback> callback) {
  overlay_subscribers_[query_id] = callback;
  callback->Success(Json{{"type", "ready"}}.dump());
}

void MeshHandler::UnsubscribeOverlayEvents(int64_t query_id) {
  overlay_subscribers_.erase(query_id);
}

void MeshHandler::EmitOverlayEvent(const Json& event) {
  const std::string payload = event.dump();
  for (auto& entry : overlay_subscribers_) {
    if (entry.second) {
      entry.second->Success(payload);
    }
  }
}

void MeshHandler::SetDevToolsDocked(bool docked) {
  CEF_REQUIRE_UI_THREAD();
  if (devtools_docked_ == docked) {
    return;
  }
  devtools_docked_ = docked;
  // Apply the new state: the docked DevTools panel follows the flag.
  LayoutContentBrowser();
}

void MeshHandler::OnGotFocus(CefRefPtr<CefBrowser> browser) {
  CEF_REQUIRE_UI_THREAD();
  // Clicking into the page or the shell chrome dismisses an open tip overlay.
  if (overlay_visible_ &&
      (IsContentBrowser(browser) || IsShellBrowser(browser))) {
    OverlayHide();
  }
}

Json MeshHandler::ContentStateJson() const {
  auto browser = ContentBrowser();
  std::string url;
  std::string title;
  if (!active_tab_id_.empty()) {
    const auto title_it = tab_titles_.find(active_tab_id_);
    if (title_it != tab_titles_.end()) {
      title = title_it->second;
    }
  }
  bool can_back = false;
  bool can_forward = false;
  bool loading = false;
  if (browser) {
    if (auto frame = browser->GetMainFrame()) {
      url = frame->GetURL().ToString();
    }
    can_back = browser->CanGoBack();
    can_forward = browser->CanGoForward();
    loading = browser->IsLoading();
  }
  return Json{{"url", url},
              {"title", title},
              {"canGoBack", can_back},
              {"canGoForward", can_forward},
              {"loading", loading},
              {"visible", content_visible_},
              {"chromeHeight", chrome_height_},
              {"memoryMb", ContentMemoryMb()},
              {"audioPlaying", content_audio_playing()},
              {"audioMuted", ContentAudioMuted()},
              {"tabId", active_tab_id_}};
}

Json MeshHandler::GetTabsListJson() const {
  Json tabs = Json::array();
  for (const auto& entry : tab_content_views_) {
    const std::string& tab_id = entry.first;
    auto view = entry.second;
    std::string url;
    std::string title;
    bool loading = false;
    const auto title_it = tab_titles_.find(tab_id);
    if (title_it != tab_titles_.end()) {
      title = title_it->second;
    }
    if (view) {
      if (auto browser = view->GetBrowser()) {
        if (auto frame = browser->GetMainFrame()) {
          url = frame->GetURL().ToString();
        }
        loading = browser->IsLoading();
      }
    }
    tabs.push_back(Json{
        {"tabId", tab_id},
        {"active", (tab_id == active_tab_id_)},
        {"url", url},
        {"title", title},
        {"loading", loading},
    });
  }
  return tabs;
}

bool MeshHandler::content_audio_playing() const {
  if (active_tab_id_.empty()) {
    return false;
  }
  const auto it = tab_audio_playing_.find(active_tab_id_);
  return it != tab_audio_playing_.end() && it->second;
}

void MeshHandler::SetContentAudioPlaying(CefRefPtr<CefBrowser> browser,
                                         bool playing) {
  CEF_REQUIRE_UI_THREAD();
  std::string tab_id = TabIdForContentBrowser(browser);
  if (tab_id.empty()) {
    tab_id = active_tab_id_;
  }
  if (tab_id.empty()) {
    return;
  }
  const auto it = tab_audio_playing_.find(tab_id);
  const bool prev = it != tab_audio_playing_.end() && it->second;
  if (prev == playing) {
    return;
  }
  tab_audio_playing_[tab_id] = playing;
  EmitBrowserEvent(Json{{"type", "audio"},
                        {"tabId", tab_id},
                        {"playing", playing},
                        {"muted", ContentAudioMuted(tab_id)}});
}

void MeshHandler::SetContentAudioMuted(bool muted) {
  SetContentAudioMuted(active_tab_id_, muted);
}

void MeshHandler::SetContentAudioMuted(const std::string& tab_id, bool muted) {
  CEF_REQUIRE_UI_THREAD();
  if (tab_id.empty()) {
    return;
  }
  auto view = ContentViewForTab(tab_id);
  if (!view) {
    return;
  }
  auto browser = view->GetBrowser();
  if (!browser) {
    return;
  }
  auto host = browser->GetHost();
  if (!host) {
    return;
  }
  if (host->IsAudioMuted() == muted) {
    return;
  }
  host->SetAudioMuted(muted);
  const auto it = tab_audio_playing_.find(tab_id);
  const bool playing = it != tab_audio_playing_.end() && it->second;
  EmitBrowserEvent(Json{{"type", "audio"},
                        {"tabId", tab_id},
                        {"playing", playing},
                        {"muted", muted}});
}

bool MeshHandler::ContentAudioMuted() const {
  return ContentAudioMuted(active_tab_id_);
}

bool MeshHandler::ContentAudioMuted(const std::string& tab_id) const {
  auto view = ContentViewForTab(tab_id);
  if (!view) {
    return false;
  }
  auto browser = view->GetBrowser();
  if (!browser) {
    return false;
  }
  auto host = browser->GetHost();
  return host && host->IsAudioMuted();
}

void MeshHandler::SetContentMedia(CefRefPtr<CefBrowser> browser,
                                  const Json& media) {
  CEF_REQUIRE_UI_THREAD();
  std::string tab_id = TabIdForContentBrowser(browser);
  if (tab_id.empty()) {
    tab_id = active_tab_id_;
  }
  if (tab_id.empty()) {
    return;
  }

  Json state = media.is_object() ? media : Json::object();
  state["tabId"] = tab_id;
  const bool active = state.value("active", false);
  const bool playing = state.value("playing", false);
  if (!active && !playing) {
    tab_media_.erase(tab_id);
  } else {
    tab_media_[tab_id] = state;
  }

  Json event = state;
  event["type"] = "media";
  EmitBrowserEvent(event);

  const bool audible = state.value("audible", playing);
  SetContentAudioPlaying(browser, audible);
}

Json MeshHandler::ContentMediaJson(const std::string& tab_id) const {
  if (tab_id.empty()) {
    return Json::object();
  }
  const auto it = tab_media_.find(tab_id);
  if (it == tab_media_.end()) {
    return Json::object();
  }
  return it->second;
}

bool MeshHandler::ContentMediaControl(const std::string& tab_id,
                                      const std::string& action,
                                      double value) {
  CEF_REQUIRE_UI_THREAD();
  if (action.empty()) {
    return false;
  }
  // Only allow known actions — values are injected as numbers.
  if (action != "toggle" && action != "play" && action != "pause" &&
      action != "seek" && action != "seekRelative" && action != "seekStart" &&
      action != "seekEnd" && action != "pip") {
    return false;
  }
  CefRefPtr<CefBrowserView> view = nullptr;
  if (!tab_id.empty()) {
    view = ContentViewForTab(tab_id);
  }
  if (!view && !active_tab_id_.empty()) {
    view = ContentViewForTab(active_tab_id_);
  }
  if (!view && !tab_content_views_.empty()) {
    view = tab_content_views_.begin()->second;
  }
  if (!view) {
    view = content_browser_view();
  }
  if (!view && !recycled_content_views_.empty()) {
    view = recycled_content_views_.front();
  }
  if (!view) {
    return false;
  }
  auto browser = view->GetBrowser();
  if (!browser) {
    return false;
  }
  auto frame = browser->GetMainFrame();
  if (!frame || !frame->IsValid()) {
    return false;
  }
  // action is already validated against a known-safe whitelist above.
  const std::string& a = action;
  const std::string v = std::to_string(value);
  const std::string script =
      std::string("(function(){"
      "try{"
      "if(typeof window.__meshMediaControl==='function'){") +
      "window.__meshMediaControl('" + a + "'," + v + ");" +
      "return;"
      "}"
      "var v=document.querySelector('video,audio');"
      "if(v){" +
      "if('" + a + "'==='toggle'){if(v.paused){v.play();}else{v.pause();}}" +
      "else if('" + a + "'==='play'){v.play();}" +
      "else if('" + a + "'==='pause'){v.pause();}" +
      "}"
      "var ytp=document.getElementById('movie_player')||document.querySelector('.html5-video-player');"
      "if(ytp){" +
      "if('" + a + "'==='toggle'){if(typeof ytp.getPlayerState==='function'&&ytp.getPlayerState()===1){ytp.pauseVideo();}else if(typeof ytp.playVideo==='function'){ytp.playVideo();}}" +
      "else if('" + a + "'==='play'&&typeof ytp.playVideo==='function'){ytp.playVideo();}" +
      "else if('" + a + "'==='pause'&&typeof ytp.pauseVideo==='function'){ytp.pauseVideo();}" +
      "}" +
      "}catch(e){}"
      "})();";
  frame->ExecuteJavaScript(script, frame->GetURL(), 0);
  return true;
}

int MeshHandler::ContentMemoryMb() const {
#if defined(OS_WIN)
  PROCESS_MEMORY_COUNTERS_EX pmc = {};
  pmc.cb = sizeof(pmc);
  if (!GetProcessMemoryInfo(GetCurrentProcess(),
                            reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc),
                            sizeof(pmc))) {
    return 0;
  }
  const SIZE_T bytes = pmc.WorkingSetSize;
  return static_cast<int>((bytes + (512ull * 1024ull)) / (1024ull * 1024ull));
#elif defined(OS_LINUX)
  std::ifstream in("/proc/self/statm");
  long pages = 0;
  if (!(in >> pages)) {
    return 0;
  }
  const long page = ::sysconf(_SC_PAGESIZE);
  if (page <= 0 || pages <= 0) {
    return 0;
  }
  const unsigned long long bytes =
      static_cast<unsigned long long>(pages) * static_cast<unsigned long long>(page);
  return static_cast<int>((bytes + (512ull * 1024ull)) / (1024ull * 1024ull));
#else
  return 0;
#endif
}

void MeshHandler::SubscribeBrowserEvents(
    int64_t query_id,
    CefRefPtr<CefMessageRouterBrowserSide::Callback> callback) {
  browser_subscribers_[query_id] = callback;
  callback->Success(ContentStateJson().dump());
}

void MeshHandler::UnsubscribeBrowserEvents(int64_t query_id) {
  browser_subscribers_.erase(query_id);
}

void MeshHandler::OnFindResult(CefRefPtr<CefBrowser> browser,
                               int identifier,
                               int count,
                               const CefRect& selectionRect,
                               int activeMatchOrdinal,
                               bool finalUpdate) {
  CEF_REQUIRE_UI_THREAD();
  (void)browser;
  (void)identifier;
  (void)selectionRect;
  if (!finalUpdate) {
    return;
  }
  EmitBrowserEvent(Json{
      {"type", "find-result"},
      {"count", count},
      {"active", activeMatchOrdinal},
  });
  EmitOverlayEvent(Json{
      {"type", "find-result"},
      {"count", count},
      {"active", activeMatchOrdinal},
  });
}

void MeshHandler::EmitBrowserEvent(const Json& event) {
  const std::string payload = event.dump();
  for (auto& entry : browser_subscribers_) {
    if (entry.second) {
      entry.second->Success(payload);
    }
  }
}

void MeshHandler::NotifyAppearanceChanged() {
  const bool dark = ChromeShouldUseDark();
  const std::string theme = dark ? "dark" : "light";
  const std::string pref = AppearancePreference();
  EmitBrowserEvent(Json{{"type", "appearance.changed"},
                        {"preference", pref},
                        {"theme", theme}});
  const std::string js =
      "(function(){var t='" + theme + "';var p='" + pref +
      "';if(window.MeshTheme&&typeof MeshTheme.applyExternal==='function'){"
      "MeshTheme.applyExternal(p,t);return;}"
      "document.documentElement.setAttribute('data-theme',t);"
      "document.documentElement.style.colorScheme=t;"
      "try{localStorage.setItem('mesh.appearance',p);}catch(e){}"
      "window.dispatchEvent(new CustomEvent('mesh-theme-change',"
      "{detail:{preference:p,theme:t}}));})();";
  for (auto& browser : browsers_) {
    if (!browser) {
      continue;
    }
    CefRefPtr<CefFrame> frame = browser->GetMainFrame();
    if (!frame || !frame->IsValid()) {
      continue;
    }
    const std::string url = frame->GetURL().ToString();
    if (url.rfind("file:", 0) != 0) {
      continue;
    }
    frame->ExecuteJavaScript(js, frame->GetURL(), 0);
  }
}

void MeshHandler::EmitContentEvent(CefRefPtr<CefBrowser> browser, Json event) {
  if (browser &&
      recycling_content_browser_ids_.count(browser->GetIdentifier()) > 0) {
    return;
  }
  const std::string tab_id = TabIdForContentBrowser(browser);
  if (tab_id.empty()) {
    // Recycled/unbound views (about:blank after a tab close) must not
    // retitle or rewrite history on the tab that is still open.
    return;
  }
  event["tabId"] = tab_id;
  EmitBrowserEvent(event);
}

void MeshHandler::ReloadUi() {
  CEF_REQUIRE_UI_THREAD();
  if (!shell_browser_view_) {
    return;
  }
  if (auto browser = shell_browser_view_->GetBrowser()) {
    browser->ReloadIgnoreCache();
  }
  OverlayHide();
  if (overlay_browser_view_) {
    if (auto browser = overlay_browser_view_->GetBrowser()) {
      browser->ReloadIgnoreCache();
    }
  }
}

void MeshHandler::StartHotReloadIfNeeded() {
  if (!IsDevMode()) {
    return;
  }
  hot_reload_.Start(paths::UiRootDir(), [this]() { ReloadUi(); });
}

bool MeshHandler::OnProcessMessageReceived(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    CefProcessId source_process,
    CefRefPtr<CefProcessMessage> message) {
  CEF_REQUIRE_UI_THREAD();
  if (!message_router_) {
    return false;
  }
  return message_router_->OnProcessMessageReceived(browser, frame,
                                                   source_process, message);
}

void MeshHandler::OnTitleChange(CefRefPtr<CefBrowser> browser,
                                const CefString& title) {
  CEF_REQUIRE_UI_THREAD();
  if (IsContentBrowser(browser)) {
    // Cache the title so ContentStateJson() can return it without a round-trip.
    const std::string tab_id = TabIdForContentBrowser(browser);
    if (!tab_id.empty()) {
      tab_titles_[tab_id] = title.ToString();
    }
    EmitContentEvent(browser,
                     Json{{"type", "title"}, {"title", title.ToString()}});
    return;
  }
  if (IsOverlayBrowser(browser)) {
    // Never let the overlay page retitle the window.
    return;
  }
  if (IsDevToolsBrowser(browser)) {
    if (auto browser_view = CefBrowserView::GetForBrowser(browser)) {
      if (auto window = browser_view->GetWindow()) {
        window->SetTitle(title);
      }
    }
    return;
  }

  std::string display = title.ToString();
  if (paths::IsPrivateMode() &&
      (display.empty() || display == "MeshBrowser")) {
    display = "Mesh Private";
  }
  if (IsDevMode()) {
    display += " [dev · hot reload]";
  }
  if (auto browser_view = CefBrowserView::GetForBrowser(browser)) {
    if (auto window = browser_view->GetWindow()) {
      window->SetTitle(display);
    }
  } else if (alloy_style_) {
    PlatformTitleChange(browser, display);
  }
}

void MeshHandler::OnAddressChange(CefRefPtr<CefBrowser> browser,
                                  CefRefPtr<CefFrame> frame,
                                  const CefString& url) {
  CEF_REQUIRE_UI_THREAD();
  if (!frame || !frame->IsMain() || !IsContentBrowser(browser)) {
    return;
  }
  EmitContentEvent(browser,
                   Json{{"type", "address"},
                        {"url", url.ToString()},
                        {"canGoBack", browser->CanGoBack()},
                        {"canGoForward", browser->CanGoForward()},
                        {"loading", browser->IsLoading()}});
}

bool MeshHandler::OnConsoleMessage(CefRefPtr<CefBrowser> browser,
                                   cef_log_severity_t level,
                                   const CefString& message,
                                   const CefString& source,
                                   int line) {
  CEF_REQUIRE_UI_THREAD();
  std::string msg = message.ToString();
  std::string src = source.ToString();
  std::string pane = IsShellBrowser(browser) ? "[Shell UI]" : (IsOverlayBrowser(browser) ? "[Overlay]" : "[Content Tab]");
  std::string lvl_str = level == LOGSEVERITY_ERROR ? "ERROR" : (level == LOGSEVERITY_WARNING ? "WARN" : "INFO");
  mesh::Log("JS Console " + pane + " [" + lvl_str + "] (" + src + ":" + std::to_string(line) + "): " + msg);
  return false;
}

void MeshHandler::OnLoadingStateChange(CefRefPtr<CefBrowser> browser,
                                       bool isLoading,
                                       bool canGoBack,
                                       bool canGoForward) {
  CEF_REQUIRE_UI_THREAD();
  if (!IsContentBrowser(browser)) {
    return;
  }
  std::string url;
  if (auto frame = browser->GetMainFrame()) {
    url = frame->GetURL().ToString();
    if (!isLoading) {
      const int browser_id = browser->GetIdentifier();
      if (recycling_content_browser_ids_.count(browser_id) > 0) {
        if (engine::IsAboutUrl(url)) {
          recycling_content_browser_ids_.erase(browser_id);
        }
      }
      MarkContentSeedIdle(browser);
      const std::string tab_id = TabIdForContentBrowser(browser);
      FlushPendingContentUrl(tab_id);
    }
  }
  EmitContentEvent(browser, Json{{"type", "loading"},
                                 {"url", url},
                                 {"loading", isLoading},
                                 {"canGoBack", canGoBack},
                                 {"canGoForward", canGoForward}});
}

void MeshHandler::OnLoadStart(CefRefPtr<CefBrowser> browser,
                              CefRefPtr<CefFrame> frame,
                              TransitionType transition_type) {
  CEF_REQUIRE_UI_THREAD();
  (void)transition_type;
  // CSS-only early pass on the main frame. Scriptlets stay off in the
  // page world (YouTube Trusted Types / CEF instability).
  if (!IsContentBrowser(browser) || !frame || !frame->IsValid() ||
      !frame->IsMain()) {
    return;
  }
  InjectAdblockCosmetics(frame);
}

void MeshHandler::OnLoadEnd(CefRefPtr<CefBrowser> browser,
                            CefRefPtr<CefFrame> frame,
                            int httpStatusCode) {
  CEF_REQUIRE_UI_THREAD();
  (void)httpStatusCode;
  if (!IsContentBrowser(browser) || !frame || !frame->IsValid() ||
      !frame->IsMain()) {
    return;
  }
  MarkContentSeedIdle(browser);
  const std::string tab_id = TabIdForContentBrowser(browser);
  FlushPendingContentUrl(tab_id);
  InjectContentPageScripts(frame);
  InjectAdblockObservers(frame);
  DevToolsClient::Get().Attach(browser);
}

void MeshHandler::OnAfterCreated(CefRefPtr<CefBrowser> browser) {
  CEF_REQUIRE_UI_THREAD();
  browsers_.push_back(browser);
  TrackBrowserIdentity(browser);

  if (!message_router_) {
    CefMessageRouterConfig config;
    message_router_ = CefMessageRouterBrowserSide::Create(config);
    library_handler_ = CreateLibraryIpcHandler(this);
    message_router_->AddHandler(library_handler_, false);
  }

  if (auto frame = browser->GetMainFrame()) {
    if (engine::IsDevToolsUrl(frame->GetURL().ToString())) {
      RegisterDevToolsBrowser(browser);
    }
  }
  // DevTools is a popup and is never bound to a tab view.
  if (browser->IsPopup() && TabIdForContentBrowser(browser).empty() &&
      !IsShellBrowser(browser) && !IsOverlayBrowser(browser)) {
    RegisterDevToolsBrowser(browser);
  }

  if (IsShellBrowser(browser)) {
    StartHotReloadIfNeeded();
  }

  if (IsDevToolsBrowser(browser)) {
    return;
  }

  if (IsContentBrowser(browser)) {
    if (auto view = CefBrowserView::GetForBrowser(browser)) {
      view->SetVisible(false);
    }
    LayoutContentBrowser();
    // Do not FlushPending here. The seed about:blank is still attaching;
    // OnLoadEnd / OnLoadingStateChange commit the queued URL.
  }
}

bool MeshHandler::DoClose(CefRefPtr<CefBrowser> browser) {
  CEF_REQUIRE_UI_THREAD();
  if (IsDevToolsBrowser(browser)) {
    return false;
  }
  if (IsShellBrowser(browser)) {
    BeginShutdown();
  }
  return false;
}

void MeshHandler::OnBeforeClose(CefRefPtr<CefBrowser> browser) {
  CEF_REQUIRE_UI_THREAD();
  const bool was_devtools = IsDevToolsBrowser(browser);
  const bool was_shell = !was_devtools && IsShellBrowser(browser);

  if (was_shell) {
    BeginShutdown();
    ForceCloseAuxiliaryBrowsers();
  }

  UntrackBrowserIdentity(browser);
  DetachAgentDevTools(browser->GetIdentifier());

  for (auto it = browsers_.begin(); it != browsers_.end(); ++it) {
    if ((*it)->IsSame(browser)) {
      browsers_.erase(it);
      break;
    }
  }

  bool shell_still_open = false;
  for (const auto& b : browsers_) {
    if (IsShellBrowser(b)) {
      shell_still_open = true;
      break;
    }
  }

  if (shutting_down_ && (browsers_.empty() || !shell_still_open)) {
    FinishShutdown();
  }
}

void MeshHandler::OnLoadError(CefRefPtr<CefBrowser> browser,
                              CefRefPtr<CefFrame> frame,
                              ErrorCode errorCode,
                              const CefString& errorText,
                              const CefString& failedUrl) {
  CEF_REQUIRE_UI_THREAD();
  mesh::Log("OnLoadError: url=" + std::string(failedUrl) +
            " code=" + std::to_string(errorCode) +
            " text=" + std::string(errorText));
  if (errorCode == ERR_ABORTED) {
    return;
  }
  if (IsDevToolsBrowser(browser)) {
    return;
  }

  if (IsContentBrowser(browser)) {
    if (!frame->IsMain()) {
      return;
    }
    std::stringstream ss;
    ss << "<html><body style='background:#121112;color:#ececec;font-family:"
          "Segoe UI,sans-serif;padding:2rem'>"
          "<h2>Can't reach this page</h2><p>"
       << std::string(failedUrl) << "</p><p>" << std::string(errorText) << " ("
       << errorCode << ")</p></body></html>";
    frame->LoadURL(GetDataURI(ss.str(), "text/html"));
    return;
  }

  std::stringstream ss;
  ss << "<html><body style='background:#1b2838;color:#c7d5e0;font-family:"
        "Segoe UI,sans-serif;padding:2rem'>"
        "<h2>Failed to load UI</h2><p>"
     << std::string(failedUrl) << "</p><p>" << std::string(errorText) << " ("
     << errorCode << ")</p>"
     << "<p>Dev mode loads <code>" << paths::UiRootDir()
     << "</code>. Release expects <code>ui/index.html</code> next to the "
        "executable.</p></body></html>";
  frame->LoadURL(GetDataURI(ss.str(), "text/html"));
}

bool MeshHandler::OnBeforePopup(CefRefPtr<CefBrowser> browser,
                                CefRefPtr<CefFrame> frame,
                                int popup_id,
                                const CefString& target_url,
                                const CefString& target_frame_name,
                                cef_window_open_disposition_t target_disposition,
                                bool user_gesture,
                                const CefPopupFeatures& popupFeatures,
                                CefWindowInfo& windowInfo,
                                CefRefPtr<CefClient>& client,
                                CefBrowserSettings& settings,
                                CefRefPtr<CefDictionaryValue>& extra_info,
                                bool* no_javascript_access) {
  CEF_REQUIRE_UI_THREAD();
  (void)browser;
  (void)frame;
  (void)popup_id;
  (void)target_disposition;
  (void)user_gesture;
  (void)popupFeatures;
  (void)client;
  (void)settings;
  (void)extra_info;
  (void)no_javascript_access;

  const std::string url = target_url.ToString();
  const std::string name = target_frame_name.ToString();

  // The engine owns the popup rule; the product owns what a tab is.
  switch (engine::DecidePopupAction(url, name)) {
    case engine::PopupAction::AllowNativeChrome:
      windowInfo.runtime_style = CEF_RUNTIME_STYLE_CHROME;
      return false;
    case engine::PopupAction::OpenInContentTab:
      // Never spawn a standalone popup window. Open the URL in a content tab
      // instead of navigating the current tab — this preserves the page that
      // triggered the popup.
      OpenUrlInNewContentTab(url);
      return true;
    case engine::PopupAction::Block:
      break;
  }
  return true;
}

void MeshHandler::OpenUrlInNewContentTab(const std::string& url) {
  CEF_REQUIRE_UI_THREAD();
  if (url.empty()) {
    return;
  }
  static int popup_tab_seq = 0;
  const std::string tab_id =
      "popup-tab-" + std::to_string(++popup_tab_seq);

  if (!shell_browser_view_) {
    mesh::Log("OnBeforePopup: no shell yet, dropping " + url);
    return;
  }
  if (!EnsureContentTab(tab_id) && ContentTabCount() >= kMaxContentTabs) {
    mesh::Log("OnBeforePopup: no room for a new tab, dropping " + url);
    return;
  }
  ActivateContentTab(tab_id);
  // The UI owns the tab bar: announce the tab with the event it already
  // understands, then navigate it.
  EmitBrowserEvent(Json{{"type", "tab.created"},
                        {"tabId", tab_id},
                        {"url", url},
                        {"activate", true}});
  ContentNavigate(url, tab_id);
  // Kept for listeners of the original popup event.
  EmitBrowserEvent(
      Json{{"type", "open-tab"}, {"url", url}, {"source", "popup"}});
}

bool MeshHandler::OnBeforeBrowse(CefRefPtr<CefBrowser> browser,
                                 CefRefPtr<CefFrame> frame,
                                 CefRefPtr<CefRequest> request,
                                 bool user_gesture,
                                 bool is_redirect) {
  CEF_REQUIRE_UI_THREAD();
  (void)user_gesture;
  (void)is_redirect;
  if (message_router_) {
    message_router_->OnBeforeBrowse(browser, frame);
  }

  // Shell/overlay must stay on local UI. Any web navigation goes to content.
  if ((IsShellBrowser(browser) || IsOverlayBrowser(browser)) && frame &&
      frame->IsMain() && request) {
    const std::string url = request->GetURL().ToString();
    if (engine::ShouldOpenInContent(url)) {
      OpenInContentBrowser(url);
      return true;
    }
  }
  return false;
}

CefRefPtr<CefResourceRequestHandler> MeshHandler::GetResourceRequestHandler(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    CefRefPtr<CefRequest> request,
    bool is_navigation,
    bool is_download,
    const CefString& request_initiator,
    bool& disable_default_handling) {
  (void)frame;
  (void)request;
  (void)is_navigation;
  (void)is_download;
  (void)request_initiator;
  disable_default_handling = false;
  if (request) {
    const std::string url = request->GetURL().ToString();
    if (engine::IsDevToolsUrl(url) || url.rfind("chrome:", 0) == 0) {
      return nullptr;
    }
  }
  // Must not call CefBrowserView APIs here (IO thread).
  if (!ShouldFilterNetwork(browser)) {
    return nullptr;
  }
  return new MeshAdblockResourceHandler(this);
}

bool MeshHandler::OnOpenURLFromTab(CefRefPtr<CefBrowser> browser,
                                   CefRefPtr<CefFrame> frame,
                                   const CefString& target_url,
                                   cef_window_open_disposition_t target_disposition,
                                   bool user_gesture) {
  CEF_REQUIRE_UI_THREAD();
  (void)frame;
  (void)target_disposition;
  (void)user_gesture;

  const std::string url = target_url.ToString();
  if (url.empty()) {
    return true;
  }

  // Ctrl/middle-click, target=_blank, and file→https handoffs.
  if (IsShellBrowser(browser) || IsContentBrowser(browser)) {
    OpenInContentBrowser(url);
    return true;
  }
  return true;
}

void MeshHandler::OnRenderProcessTerminated(CefRefPtr<CefBrowser> browser,
                                            TerminationStatus status,
                                            int error_code,
                                            const CefString& error_string) {
  CEF_REQUIRE_UI_THREAD();
  const std::string reason =
      "Renderer crashed (status=" + std::to_string(status) +
      " error_code=" + std::to_string(error_code) +
      " error_string=" + std::string(error_string) + ")";
  mesh::LogCrash("OnRenderProcessTerminated: " + reason);
  FailPendingAgentQueries(reason);
  if (message_router_) {
    message_router_->OnRenderProcessTerminated(browser);
  }
  // Do not Reload() here. Wikipedia-sized pages OOM the renderer; reloading
  // them from this callback often kills the browser process too. Leave the
  // pane; the user or agent can navigate again.
}

void MeshHandler::PlatformTitleChange(CefRefPtr<CefBrowser> browser,
                                      const CefString& title) {
#if defined(OS_WIN)
  CefWindowHandle hwnd = browser->GetHost()->GetWindowHandle();
  if (hwnd) {
    SetWindowTextW(hwnd, title.ToWString().c_str());
  }
#else
  (void)browser;
  (void)title;
#endif
}

void MeshHandler::OnDraggableRegionsChanged(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    const std::vector<CefDraggableRegion>& regions) {
  CEF_REQUIRE_UI_THREAD();
  (void)frame;
  // Only the shell defines window drag regions; the overlay must never
  // clear or override them.
  if (!IsShellBrowser(browser)) {
    return;
  }
  ApplyDraggableRegions(browser, regions);
}

void MeshHandler::ApplyDraggableRegions(
    CefRefPtr<CefBrowser> browser,
    const std::vector<CefDraggableRegion>& regions) {
  auto browser_view = CefBrowserView::GetForBrowser(browser);
  if (!browser_view) {
    return;
  }
  auto window = browser_view->GetWindow();
  if (!window) {
    return;
  }

  std::vector<CefDraggableRegion> window_regions = regions;
  for (auto& region : window_regions) {
    CefPoint origin(region.bounds.x, region.bounds.y);
    browser_view->ConvertPointToWindow(origin);
    region.bounds.x = origin.x;
    region.bounds.y = origin.y;
  }
  window->SetDraggableRegions(window_regions);
}

}  // namespace mesh
